Report is in current folder.

Code folder contains:

1) Q1_SMDP folder contains 
	a.	SMDP, Intra-Option implementation
	b.	Plotter file
	c.	environment folder 
	d.	numpy saves folder for reproducing figures 

2) Q2_DQN folder contains
	a.	Cartpole DQN implementation
	b.	Various experiments files for different hyperparameter
	c.	Experiment file for bonus question along with plotter file
	d.	numpy save for plotting

