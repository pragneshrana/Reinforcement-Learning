Code folder contains two files:

1. 'epsilonGreedy_Softmax_UCB1.py' it contains implementation of epsilonGreedy, Softmax & UCB1 algorithm along with code for plotting Average rewards, % optimal action pulls figures for all three algorithms.
2. 'MEA.py' contains implementation of Median Elimination algorithm along with code for plotting graphs.

Report.pdf is in current folder